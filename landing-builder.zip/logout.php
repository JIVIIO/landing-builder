<?php
require_once __DIR__ . '/helpers.php';
// Завершаем сессию и перенаправляем на страницу входа
session_destroy();
header('Location: login.php');
exit;