<?php
// config.php

// Настройки подключения к базе данных
define('DB_HOST', 'localhost');
define('DB_NAME', 'landing_builder');
define('DB_USER', 'db_user');
define('DB_PASS', 'db_pass');
define('DB_CHARSET', 'utf8mb4');

// Основной домен сервиса. Измените на свой домен.
define('MAIN_DOMAIN', 'mybuilder.com');