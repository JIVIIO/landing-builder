<?php
// helpers.php

require_once __DIR__ . '/db.php';

// Стартуем сессию, если она ещё не запущена
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Возвращает текущего пользователя как ассоциативный массив или null,
 * если пользователь не авторизован.
 *
 * @return array|null
 */
function currentUser(): ?array {
    if (!isset($_SESSION['user_id'])) {
        return null;
    }
    $pdo = getPDO();
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
    return $user ?: null;
}

/**
 * Перенаправляет неавторизованного пользователя на страницу входа.
 */
function requireLogin(): void {
    if (!currentUser()) {
        header('Location: login.php');
        exit;
    }
}

/**
 * Приводит строку к формату поддомена: латиница, цифры и дефисы.
 *
 * @param string $slug
 * @return string
 */
function sanitizeSlug(string $slug): string {
    $slug = strtolower(trim($slug));
    // Заменяем запрещённые символы на дефисы
    $slug = preg_replace('/[^a-z0-9\-]/', '-', $slug);
    // Сжимаем повторяющиеся дефисы
    $slug = preg_replace('/-+/', '-', $slug);
    return trim($slug, '-');
}

/**
 * Ищет опубликованный сайт по slug.
 *
 * @param string $slug
 * @return array|null
 */
function findSiteBySlug(string $slug): ?array {
    $pdo = getPDO();
    $stmt = $pdo->prepare("SELECT * FROM sites WHERE slug = ? AND is_published = 1");
    $stmt->execute([$slug]);
    $site = $stmt->fetch();
    return $site ?: null;
}

/**
 * Получает конфиг блока типа 'page' для указанного сайта.
 *
 * @param int $site_id
 * @return array|null
 */
function getSiteBlockConfig(int $site_id): ?array {
    $pdo = getPDO();
    $stmt = $pdo->prepare("SELECT * FROM site_blocks WHERE site_id = ? AND block_type = 'page' LIMIT 1");
    $stmt->execute([$site_id]);
    $row = $stmt->fetch();
    if (!$row) return null;
    return json_decode($row['config'], true);
}